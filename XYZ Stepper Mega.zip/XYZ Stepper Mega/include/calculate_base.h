#ifndef CALCULATE_BASE_H
#define CALCULATE_BASE_H

int calculateX(int);
int calculateY(int);
void calculateXY(int, int, int, int, double*, double*);
void calculateZ(int, double*);

#endif