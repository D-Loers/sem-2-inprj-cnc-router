#ifndef EXAMPLE_H
#define EXAMPLE_H
#include <Arduino.h>

String exampleCode(int);

#endif