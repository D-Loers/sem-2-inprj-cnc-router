#ifndef LOGIC_H
#define LOGIC_H
#include <Arduino.h>

void showSteps(int, int, int);
void stepsTaken(char, int);

#endif